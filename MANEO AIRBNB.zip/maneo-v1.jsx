// V1 — Éditorial classique : structure Airbnb sobre, hero texte fort, sections claires

function ManeoV1({ density = "comfortable", logoVariant = "A", tw = {} }) {
  const Logo = { A: ManeoLogoA, B: ManeoLogoB, C: ManeoLogoC }[logoVariant] || ManeoLogoA;
  const pad = density === "compact" ? { sec: 56, gap: 24 } : { sec: 96, gap: 40 };

  // Tweaks defaults
  const headline = tw.headline || "langue";
  const titleStyle = tw.titleStyle || "default";
  const accentStyle = tw.accentStyle || "shimmer";
  const heroLayout = tw.heroLayout || "collage";
  const featured = tw.featured ?? "pro";
  const cardStyle = tw.cardStyle || "border";
  const radius = tw.radius ?? 16;
  const intensity = tw.intensity || "medium";
  const featuredBg = tw.featuredBg || "dark";
  const showApp = tw.showApp ?? true;
  const showProcess = tw.showProcess ?? true;
  const showTrades = tw.showTrades ?? true;
  const showTesti = tw.showTesti ?? true;
  const ctaBg = tw.ctaBg || "beige";

  const HEADLINES = {
    langue:   { pre: "L'agence web", main: "qui parle", em: "ta langue.", eyebrow: "Le digital fait main" },
    livre:    { pre: "Ton site pro,", main: "livré en", em: "15 jours.", eyebrow: "Prix fixe · Sans surprise" },
    prix:     { pre: "990€.", main: "Pas un", em: "de plus.", eyebrow: "Le pack tout compris" },
  };
  const H = HEADLINES[headline] || HEADLINES.langue;

  const titleFont = titleStyle === "serif" ? "var(--font-serif, 'Playfair Display', Georgia, serif)"
                  : titleStyle === "mono" ? "ui-monospace, 'JetBrains Mono', Menlo, monospace"
                  : "var(--font-sans)";

  const accentCSS = {
    shimmer: `background: linear-gradient(90deg, var(--accent) 0%, var(--accent) 35%, var(--accent-2, #06B6D4) 50%, var(--accent) 65%, var(--accent) 100%); background-size: 200% 100%; -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; animation: v1shimmer 5s linear infinite; font-style: italic;`,
    underline: `color: var(--accent); font-style: italic; text-decoration: underline; text-decoration-thickness: 4px; text-underline-offset: 6px;`,
    highlight: `color: var(--ink, #222); font-style: normal; background: linear-gradient(180deg, transparent 60%, color-mix(in oklab, var(--accent) 35%, transparent) 60%); padding: 0 4px;`,
    none:      `color: var(--accent); font-style: italic;`,
  }[accentStyle];

  const featuredId = featured === "none" ? null : featured;
  const PACKS = MANEO_PACKS.map(p => ({ ...p, accent: featuredId === p.id, badge: featuredId === p.id ? p.badge : null }));

  const cardCSS = {
    border:   `border: 1px solid #ebebeb; background: #fff;`,
    thick:    `border: 2px solid var(--ink, #222); background: #fff;`,
    elevated: `border: 1px solid transparent; background: #fff; box-shadow: 0 4px 16px rgba(0,0,0,0.06);`,
    tinted:   `border: 1px solid color-mix(in oklab, var(--accent) 15%, #ebebeb); background: var(--bg-soft, #fafafa);`,
  }[cardStyle];

  const featuredBgCSS = {
    dark:    `background: #222; color: #fff; border-color: #222;`,
    accent:  `background: var(--accent-dark, var(--accent)); color: #fff; border-color: var(--accent-dark, var(--accent));`,
    cream:   `background: #FAF7F2; color: #222; border-color: var(--accent);`,
  }[featuredBg];
  const featuredText = featuredBg === "cream" ? "rgba(60,60,60,0.7)" : "rgba(255,255,255,0.7)";
  const featuredText2 = featuredBg === "cream" ? "#222" : "#fff";

  const sectionBg = intensity === "immersive" ? "color-mix(in oklab, var(--accent) 5%, #fff)" : "#fff";
  const ctaBgCSS = ctaBg === "accent" ? "color-mix(in oklab, var(--accent) 8%, #fff)"
                : ctaBg === "gradient" ? "linear-gradient(135deg, color-mix(in oklab, var(--accent) 10%, #fff) 0%, color-mix(in oklab, var(--accent-2, var(--accent)) 12%, #fff) 100%)"
                : "#FAF7F2";
  const css = `
    @keyframes v1float { 0%, 100% { transform: translateY(0); } 50% { transform: translateY(-8px); } }
    @keyframes v1shimmer { 0% { background-position: -200% 0; } 100% { background-position: 200% 0; } }
    .v1 { font-family: var(--font-sans); color: #222; background: #fff; width: 1280px; }
    .v1 h1 { font-family: ${titleFont}; }
    .v1 h2 { font-family: ${titleFont}; }
    .v1 h1 em.shimmer { ${accentCSS} }
    .v1 .pack { ${cardCSS} padding: 36px 32px; border-radius: ${radius + 4}px; transition: transform 250ms cubic-bezier(0.2,0,0,1), box-shadow 250ms, border-color 250ms; display: flex; flex-direction: column; position: relative; }
    .v1 .pack.featured { ${featuredBgCSS} transform: translateY(-12px); box-shadow: 0 24px 60px rgba(0,0,0,0.18); }
    .v1 .pack.featured .pack-tagline, .v1 .pack.featured .pack-meta-item { color: ${featuredText}; }
    .v1 .pack.featured .pack-li { color: ${featuredText2}; }
    .v1 .pack.featured .pack-num { color: ${featuredText2}; }
    .v1 .pack.featured .pack-divider { border-color: rgba(255,255,255,0.18); }
    .v1 .section { background: ${sectionBg}; }
    .v1 .cta { background: ${ctaBgCSS}; }
    .v1 .btn { border-radius: ${Math.min(radius + 999, 999)}px; }
    .v1 .step, .v1 .testi-card, .v1 .trade-chip, .v1 .cta-form, .v1 .field input, .v1 .field select { border-radius: ${radius}px; }
    .v1 .app-band { border-radius: ${radius + 4}px; }
    .v1 .hero-collage > * { animation: v1float 6s ease-in-out infinite; }
    .v1 .hero-collage > :nth-child(2) { animation-delay: 1.5s; }
    .v1 .hero-collage > :nth-child(3) { animation-delay: 3s; }
    .v1 h1 em.shimmer { background: linear-gradient(90deg, var(--accent) 0%, var(--accent) 35%, var(--accent-2, #FFB347) 50%, var(--accent) 65%, var(--accent) 100%); background-size: 200% 100%; -webkit-background-clip: text; background-clip: text; -webkit-text-fill-color: transparent; animation: v1shimmer 5s linear infinite; font-style: italic; display: inline-block; }
    .v1 .hd { position: sticky; top: 0; background: rgba(255,255,255,0.96); backdrop-filter: blur(8px); border-bottom: 1px solid #ebebeb; z-index: 10; }
    .v1 .hd-in { display: flex; align-items: center; padding: 18px 56px; gap: 32px; }
    .v1 .nav { flex: 1; display: flex; gap: 28px; justify-content: center; }
    .v1 .nav a { font-size: 14px; font-weight: 500; color: #484848; text-decoration: none; cursor: pointer; }
    .v1 .nav a:hover { color: #222; }
    .v1 .btn { display: inline-flex; align-items: center; gap: 8px; padding: 12px 20px; border-radius: 999px; font-size: 14px; font-weight: 600; cursor: pointer; border: none; font-family: inherit; }
    .v1 .btn-primary { background: var(--accent); color: #fff; }
    .v1 .btn-primary:hover { background: var(--accent-dark); }
    .v1 .btn-ghost { background: transparent; color: #222; border: 1px solid #ddd; }
    .v1 .btn-ghost:hover { border-color: #222; }
    .v1 .btn-lg { padding: 16px 28px; font-size: 16px; }
    .v1 .container { max-width: 1180px; margin: 0 auto; padding: 0 56px; }
    .v1 .eyebrow { font-size: 13px; font-weight: 600; color: var(--accent); letter-spacing: 0.04em; text-transform: uppercase; }
    .v1 h1 { font-size: 76px; font-weight: 800; letter-spacing: -0.035em; line-height: 0.98; margin: 16px 0 24px; }
    .v1 h1 em { font-style: normal; color: var(--accent); }
    .v1 .lede { font-size: 20px; line-height: 1.5; color: #484848; max-width: 620px; }
    .v1 h2 { font-size: 44px; font-weight: 700; letter-spacing: -0.025em; line-height: 1.05; margin: 0 0 16px; }
    .v1 h3 { font-size: 22px; font-weight: 600; margin: 0 0 8px; letter-spacing: -0.01em; }
    .v1 .hero { padding: ${pad.sec}px 0 ${pad.sec}px; display: grid; grid-template-columns: 1.1fr 0.9fr; gap: 56px; align-items: center; }
    .v1 .hero-meta { display: flex; gap: 20px; margin-top: 32px; flex-wrap: wrap; }
    .v1 .hero-meta-item { display: flex; align-items: center; gap: 8px; font-size: 14px; font-weight: 500; color: #222; }
    .v1 .hero-meta-item .dot { width: 6px; height: 6px; border-radius: 50%; background: var(--accent); }
    .v1 .hero-cta { display: flex; gap: 12px; margin-top: 36px; }
    .v1 .hero-collage { display: grid; grid-template-columns: 1fr 1fr; grid-template-rows: 1fr 1fr; gap: 12px; aspect-ratio: 1/1; }
    .v1 .hero-collage > :first-child { grid-row: 1 / 3; }
    .v1 .section { padding: ${pad.sec}px 0; border-top: 1px solid #ebebeb; }
    .v1 .section-head { display: flex; align-items: end; justify-content: space-between; margin-bottom: ${pad.gap}px; gap: 32px; }
    .v1 .section-head p { color: #767676; font-size: 17px; max-width: 480px; margin: 0; }
    .v1 .packs { display: grid; grid-template-columns: repeat(3, 1fr); gap: 20px; align-items: stretch; }
    .v1 .pack { padding: 36px 32px; border: 1px solid #ebebeb; border-radius: 20px; background: #fff; transition: transform 250ms cubic-bezier(0.2,0,0,1), box-shadow 250ms, border-color 250ms; display: flex; flex-direction: column; position: relative; }
    .v1 .pack:hover { transform: translateY(-6px); box-shadow: 0 18px 40px rgba(0,0,0,0.10); border-color: #e0e0e0; }
    .v1 .pack.featured { background: #222; color: #fff; border-color: #222; transform: translateY(-12px); box-shadow: 0 24px 60px rgba(0,0,0,0.18); }
    .v1 .pack.featured:hover { transform: translateY(-18px); box-shadow: 0 32px 80px rgba(0,0,0,0.24); }
    .v1 .pack.featured .pack-tagline, .v1 .pack.featured .pack-meta-item { color: rgba(255,255,255,0.7); }
    .v1 .pack.featured .pack-li { color: rgba(255,255,255,0.92); }
    .v1 .pack.featured .pack-num { color: #fff; }
    .v1 .pack.featured .pack-divider { border-color: rgba(255,255,255,0.18); }
    .v1 .pack-badge { position: absolute; top: -12px; left: 50%; transform: translateX(-50%); background: var(--accent); color: #fff; font-size: 11px; font-weight: 700; letter-spacing: 0.08em; padding: 6px 14px; border-radius: 999px; text-transform: uppercase; box-shadow: 0 4px 14px rgba(0,0,0,0.18); }
    .v1 .pack-name { font-size: 14px; font-weight: 700; letter-spacing: 0.06em; text-transform: uppercase; color: var(--accent); margin: 0 0 6px; }
    .v1 .pack.featured .pack-name { color: var(--accent); }
    .v1 .pack-tagline { font-size: 16px; line-height: 1.4; color: #767676; margin: 0 0 28px; min-height: 44px; }
    .v1 .pack-price { display: flex; align-items: baseline; gap: 6px; margin-bottom: 8px; }
    .v1 .pack-num { font-size: 56px; font-weight: 800; letter-spacing: -0.04em; line-height: 1; color: #222; }
    .v1 .pack-currency { font-size: 26px; font-weight: 600; color: #767676; }
    .v1 .pack-price-meta { font-size: 13px; color: #767676; margin-bottom: 24px; }
    .v1 .pack.featured .pack-price-meta { color: rgba(255,255,255,0.65); }
    .v1 .pack-meta { display: flex; gap: 16px; padding: 14px 0; border-top: 1px solid #ebebeb; border-bottom: 1px solid #ebebeb; margin-bottom: 24px; }
    .v1 .pack-meta-item { font-size: 13px; color: #484848; display: flex; align-items: center; gap: 6px; }
    .v1 .pack-meta-item b { color: #222; font-weight: 600; }
    .v1 .pack.featured .pack-meta-item b { color: #fff; }
    .v1 .pack-divider { border-top: 1px solid #ebebeb; }
    .v1 .pack ul { list-style: none; padding: 0; margin: 0 0 28px; display: flex; flex-direction: column; gap: 12px; flex: 1; }
    .v1 .pack-li { display: flex; gap: 12px; font-size: 14.5px; line-height: 1.45; color: #484848; }
    .v1 .pack-li svg { color: var(--accent); flex-shrink: 0; margin-top: 2px; }
    .v1 .pack .btn { width: 100%; justify-content: center; }
    .v1 .pack-cta-ghost { background: transparent; color: #222; border: 1px solid #222; }
    .v1 .pack-cta-ghost:hover { background: #222; color: #fff; }
    .v1 .pack.featured .pack-cta-ghost { color: #fff; border-color: #fff; }
    .v1 .pack.featured .pack-cta-ghost:hover { background: #fff; color: #222; }
    .v1 .pack-foot { font-size: 12px; color: #767676; margin: 16px 0 0; text-align: center; }
    .v1 .pack.featured .pack-foot { color: rgba(255,255,255,0.6); }
    /* App offer band */
    .v1 .app-band { margin-top: 56px; padding: 40px; border-radius: 20px; background: linear-gradient(135deg, #FAF7F2 0%, #F0EBE2 100%); display: grid; grid-template-columns: 1.4fr 1fr; gap: 40px; align-items: center; }
    .v1 .app-band h3 { font-size: 28px; margin: 0 0 8px; }
    .v1 .app-band p { font-size: 16px; color: #484848; margin: 0 0 20px; }
    .v1 .process { display: grid; grid-template-columns: repeat(3, 1fr); gap: 24px; }
    .v1 .step { padding: 28px; border: 1px solid #ebebeb; border-radius: 16px; }
    .v1 .step-num { font-size: 13px; font-weight: 700; color: var(--accent); letter-spacing: 0.05em; }
    .v1 .step h3 { font-size: 19px; margin: 12px 0 8px; }
    .v1 .step p { font-size: 14px; color: #767676; margin: 0; line-height: 1.5; }
    .v1 .trades { display: flex; gap: 12px; flex-wrap: wrap; }
    .v1 .trade-chip { display: inline-flex; align-items: center; gap: 8px; padding: 12px 18px; border-radius: 999px; border: 1px solid #ebebeb; font-size: 14px; font-weight: 500; }
    .v1 .testi { display: grid; grid-template-columns: repeat(2, 1fr); gap: 24px; }
    .v1 .testi-card { padding: 28px; border: 1px solid #ebebeb; border-radius: 16px; display: grid; grid-template-columns: 100px 1fr; gap: 20px; align-items: start; }
    .v1 .testi-quote { font-size: 17px; line-height: 1.45; color: #222; margin: 0 0 16px; }
    .v1 .testi-meta { font-size: 14px; color: #767676; }
    .v1 .testi-meta b { color: #222; font-weight: 600; }
    .v1 .testi-stars { display: inline-flex; gap: 2px; color: #222; margin-bottom: 12px; }
    .v1 .cta { padding: ${pad.sec}px 0; background: #FAF7F2; border-radius: 24px; margin: ${pad.sec}px 56px; padding: 64px; display: grid; grid-template-columns: 1.2fr 0.8fr; gap: 48px; align-items: center; }
    .v1 .cta h2 { margin: 0 0 16px; }
    .v1 .cta-form { background: #fff; padding: 28px; border-radius: 16px; border: 1px solid #ebebeb; box-shadow: 0 6px 20px rgba(0,0,0,0.06); }
    .v1 .field { display: flex; flex-direction: column; gap: 6px; margin-bottom: 16px; }
    .v1 .field label { font-size: 11px; font-weight: 700; letter-spacing: 0.06em; text-transform: uppercase; color: #767676; }
    .v1 .field input, .v1 .field select { padding: 12px; border: 1px solid #ddd; border-radius: 8px; font-family: inherit; font-size: 15px; background: #fff; }
    .v1 .ft { padding: 48px 56px 32px; background: #F7F7F7; }
    .v1 .ft-grid { display: grid; grid-template-columns: 2fr 1fr 1fr 1fr; gap: 32px; max-width: 1180px; margin: 0 auto 32px; }
    .v1 .ft h4 { font-size: 13px; font-weight: 700; margin: 0 0 12px; }
    .v1 .ft ul { list-style: none; padding: 0; margin: 0; }
    .v1 .ft li { font-size: 14px; color: #484848; padding: 4px 0; cursor: pointer; }
    .v1 .ft-bottom { max-width: 1180px; margin: 0 auto; padding-top: 24px; border-top: 1px solid #ddd; display: flex; justify-content: space-between; font-size: 13px; color: #767676; }
  `;
  return (
    <div className="v1">
      <style dangerouslySetInnerHTML={{ __html: css }} />

      <header className="hd">
        <div className="hd-in">
          <Logo size={26} />
          <nav className="nav">
            <a>Le site à 990€</a>
            <a>L'appli sur mesure</a>
            <a>Comment ça marche</a>
            <a>Réalisations</a>
            <a>Tarifs</a>
          </nav>
          <button className="btn btn-primary">Voir des exemples</button>
        </div>
      </header>

      <div className="container">
        <section className="hero">
          <div>
            <div className="eyebrow">{H.eyebrow}</div>
            <h1>{H.pre}<br />{H.main} <em className="shimmer">{H.em}</em></h1>
            <p className="lede">Pendant 8 ans j'ai bossé dans le sanitaire chez Presto. J'ai vu trop d'artisans perdre des clients à cause d'un site pourri — ou pas de site du tout. Du coup je code. Pour vous.</p>
            <div className="hero-meta">
              <div className="hero-meta-item"><span className="dot"></span>À partir de 990€ · prix fixe</div>
              <div className="hero-meta-item"><span className="dot"></span>Livré en 15 jours</div>
              <div className="hero-meta-item"><span className="dot"></span>Zéro jargon</div>
            </div>
            <div className="hero-cta">
              <button className="btn btn-primary btn-lg">Voir des exemples<Icon.Arrow size={16} /></button>
              <button className="btn btn-ghost btn-lg">Comment ça marche</button>
            </div>
          </div>
          {heroLayout === "collage" && (
            <div className="hero-collage">
              <CraftPlaceholder kind="portrait" tone="warm" />
              <CraftPlaceholder kind="tools" tone="sage" />
              <CraftPlaceholder kind="site" tone="sand" />
            </div>
          )}
          {heroLayout === "single" && (
            <div style={{ aspectRatio: "1/1", borderRadius: radius + 8, overflow: "hidden" }}>
              <CraftPlaceholder kind="portrait" tone="warm" />
            </div>
          )}
          {heroLayout === "minimal" && (
            <div style={{ aspectRatio: "1/1", borderRadius: radius + 8, background: "color-mix(in oklab, var(--accent) 12%, #fff)", display: "flex", alignItems: "center", justifyContent: "center", padding: 48 }}>
              <Logo size={120} />
            </div>
          )}
        </section>

        <section className="section" id="offres">
          <div className="section-head">
            <div>
              <div className="eyebrow">Trois packs · prix fixe</div>
              <h2>Choisis le tien.<br />On démarre demain.</h2>
            </div>
            <p>Pas de menu à rallonge, pas d'options cachées. Tu choisis un pack, je m'y tiens. Le devis qu'on signe est celui qu'on paie.</p>
          </div>
          <div className="packs">
            {PACKS.map((pk, i) =>
            <Reveal key={pk.id} delay={i * 80}>
                <article className={`pack${pk.accent ? " featured" : ""}`}>
                  {pk.badge && <div className="pack-badge">{pk.badge}</div>}
                  <div className="pack-name">{pk.name}</div>
                  <p className="pack-tagline">{pk.tagline}</p>
                  <div className="pack-price">
                    <span className="pack-num">{pk.price.toLocaleString("fr-FR")}</span>
                    <span className="pack-currency">€</span>
                  </div>
                  <div className="pack-price-meta">prix fixe, tout compris · TVA non applicable</div>
                  <div className="pack-meta">
                    <div className="pack-meta-item"><Icon.Calendar size={14} /><b>{pk.delay}</b></div>
                    <div className="pack-meta-item"><Icon.Layers size={14} /><b>{pk.pages}</b></div>
                  </div>
                  <ul>
                    {pk.features.map((f, j) =>
                  <li key={j} className="pack-li"><Icon.Check size={18} />{f}</li>
                  )}
                  </ul>
                  <button className={`btn ${pk.accent ? "btn-primary" : "pack-cta-ghost"} btn-lg`}>{pk.cta}<Icon.Arrow size={16} /></button>
                  <p className="pack-foot">Garantie 15 jours satisfait ou remboursé</p>
                </article>
              </Reveal>
            )}
          </div>

        {showApp && (
          <div className="app-band">
            <div>
              <div className="eyebrow" style={{ color: "#00A699" }}>Et pour aller plus loin</div>
              <h3>Une appli métier sur mesure.</h3>
              <p>Devis automatique, planning chantiers, fiches clients. L'outil pro qui te fait gagner 5h par semaine — pour les artisans qui veulent passer la vitesse supérieure.</p>
              <button className="btn btn-ghost">Découvrir l'appli sur mesure<Icon.Arrow size={16} /></button>
            </div>
            <div><CraftPlaceholder kind="laptop" tone="sky" aspect="4/3" /></div>
          </div>
        )}
        </section>

        {showProcess && (
        <section className="section">
          <div className="section-head">
            <div>
              <div className="eyebrow">Comment ça marche</div>
              <h2>3 étapes. 15 jours.</h2>
            </div>
          </div>
          <div className="process">
            <div className="step">
              <div className="step-num">01 · JOUR 1</div>
              <h3>On parle 1h</h3>
              <p>Chez toi, dans ton atelier ou ton magasin. Tu me racontes ton métier, tes clients, ce qui te saoule. Je prends des notes. Pas de PowerPoint.</p>
            </div>
            <div className="step">
              <div className="step-num">02 · JOUR 2 → 12</div>
              <h3>Je code</h3>
              <p>Je te montre une première version au bout de 5 jours. Tu me dis ce qui colle, ce qui colle pas. Je rectifie. C'est ton site.</p>
            </div>
            <div className="step">
              <div className="step-num">03 · JOUR 15</div>
              <h3>En ligne</h3>
              <p>On met en ligne ensemble. Je te montre comment changer un texte, une photo. Tu repars autonome. Et je reste joignable.</p>
            </div>
          </div>
        </section>
        )}

        {showTrades && (
        <section className="section">
          <div className="section-head">
            <div>
              <div className="eyebrow">Pour qui</div>
              <h2>Artisans, commerçants,<br />indépendants.</h2>
            </div>
            <p>Si tu fais un métier avec tes mains, ou que tu tiens une boutique, on est faits pour bosser ensemble.</p>
          </div>
          <div className="trades">
            {MANEO_TRADES.map((t) => {
              const I = Icon[t.icon];
              return <div key={t.label} className="trade-chip"><I size={18} />{t.label}</div>;
            })}
            <div className="trade-chip" style={{ borderStyle: "dashed", color: "#767676" }}>+ et tous les autres</div>
          </div>
        </section>
        )}

        {showTesti && (
        <section className="section">
          <div className="section-head">
            <div>
              <div className="eyebrow">Ils m'ont fait confiance</div>
              <h2>Des sites qui bossent<br />pour eux pendant qu'ils bossent.</h2>
            </div>
          </div>
          <div className="testi">
            {MANEO_REVIEWS.slice(0, 4).map((r) =>
            <div key={r.name} className="testi-card">
                <div style={{ aspectRatio: "1/1" }}><CraftPlaceholder kind={r.kind} tone={r.tone} /></div>
                <div>
                  <div className="testi-stars">{[0, 1, 2, 3, 4].map((i) => <Icon.Star key={i} size={14} />)}</div>
                  <p className="testi-quote">« {r.quote} »</p>
                  <div className="testi-meta"><b>{r.name}</b> · {r.trade}</div>
                </div>
              </div>
            )}
          </div>
        </section>
        )}
      </div>

      <section className="cta">
        <div>
          <div className="eyebrow">On commence quand ?</div>
          <h2>1h de discussion.<br />Gratuit. Sans engagement.</h2>
          <p style={{ fontSize: 17, color: "#484848", maxWidth: 460, marginTop: 16 }}>Tu me racontes ton métier, je te dis ce que je peux faire pour toi. Si on se sent pas, on se sert la main et c'est tout.</p>
        </div>
        <form className="cta-form" onSubmit={(e) => e.preventDefault()}>
          <div className="field">
            <label>Ton nom</label>
            <input placeholder="Karim Bouazza" />
          </div>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12 }}>
            <div className="field">
              <label>Ton métier</label>
              <select defaultValue=""><option value="" disabled>Choisis</option><option>Plombier</option><option>Électricien</option><option>Maçon</option><option>Boulanger</option><option>Coiffeur</option><option>Autre</option></select>
            </div>
            <div className="field">
              <label>Ville</label>
              <input placeholder="Lyon" />
            </div>
          </div>
          <div className="field">
            <label>Ton tel</label>
            <input placeholder="06…" />
          </div>
          <button className="btn btn-primary btn-lg" style={{ width: "100%", justifyContent: "center" }}>Caler 1h<Icon.Arrow size={16} /></button>
          <div style={{ fontSize: 12, color: "#767676", marginTop: 12, textAlign: "center" }}>Réponse dans la journée. Promis.</div>
        </form>
      </section>

      <footer className="ft">
        <div className="ft-grid">
          <div>
            <Logo size={22} />
            <p style={{ fontSize: 14, color: "#767676", marginTop: 12, lineHeight: 1.5, maxWidth: 280 }}>L'agence web qui parle ta langue. Sites pros pour artisans et commerçants.</p>
          </div>
          <div><h4>Offres</h4><ul><li>Site à 990€</li><li>Appli sur mesure</li><li>Maintenance</li></ul></div>
          <div><h4>Manéo</h4><ul><li>Mon histoire</li><li>Réalisations</li><li>Tarifs</li></ul></div>
          <div><h4>Contact</h4><ul><li>06 12 34 56 78</li><li>salut@maneo.fr</li><li>Lyon, France</li></ul></div>
        </div>
        <div className="ft-bottom">
          <span>© 2026 Manéo · SIRET 900 123 456</span>
          <span>Mentions légales · Confidentialité</span>
        </div>
      </footer>
    </div>);

}

window.ManeoV1 = ManeoV1;