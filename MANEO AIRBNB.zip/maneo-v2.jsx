// V2 — Catalogue produit : présente les services comme des "listings" Airbnb avec carte de réservation sticky

function ManeoV2({ density = "comfortable", logoVariant = "B" }) {
  const Logo = { A: ManeoLogoA, B: ManeoLogoB, C: ManeoLogoC }[logoVariant] || ManeoLogoB;
  const pad = density === "compact" ? { sec: 48 } : { sec: 80 };
  const css = `
    .v2 { font-family: var(--font-sans); color: #222; background: #fff; width: 1280px; }
    @keyframes v2pulse { 0%, 100% { opacity: 1; transform: scale(1); } 50% { opacity: 0.85; transform: scale(1.04); } }
    @keyframes v2slide { from { opacity: 0; transform: translateY(8px); } to { opacity: 1; transform: translateY(0); } }
    .v2 .listing-head { animation: v2slide 600ms cubic-bezier(0.2,0,0,1); }
    .v2 .gallery > *:not(.gallery-btn) { transition: transform 350ms cubic-bezier(0.2,0,0,1); }
    .v2 .gallery:hover > *:not(:hover):not(.gallery-btn) { opacity: 0.85; }
    .v2 .gallery > *:not(.gallery-btn):hover { transform: scale(1.015); z-index: 2; }
    .v2 .reserve-btn { transition: transform 200ms, background 200ms; }
    .v2 .reserve-btn:hover { transform: translateY(-1px); animation: v2pulse 2s ease-in-out infinite; }
    .v2 .feature svg { transition: transform 250ms cubic-bezier(0.2,0,0,1); }
    .v2 .feature:hover svg { transform: scale(1.15) rotate(-4deg); color: var(--accent); }
    .v2 .hd { position: sticky; top: 0; background: #fff; border-bottom: 1px solid #ebebeb; z-index: 10; }
    .v2 .hd-in { display: flex; align-items: center; padding: 16px 56px; gap: 24px; }
    .v2 .hd-search { display: flex; align-items: center; gap: 0; border: 1px solid #ddd; border-radius: 999px; padding: 4px 4px 4px 18px; box-shadow: 0 2px 4px rgba(0,0,0,0.06); flex: 0 0 auto; margin: 0 auto; }
    .v2 .hd-search-seg { padding: 8px 16px; font-size: 14px; font-weight: 500; cursor: pointer; }
    .v2 .hd-search-seg + .hd-search-seg { border-left: 1px solid #ebebeb; }
    .v2 .hd-search-seg span { display: block; font-size: 12px; color: #767676; font-weight: 400; }
    .v2 .hd-search-cta { background: var(--accent); color: #fff; width: 36px; height: 36px; border-radius: 50%; display: flex; align-items: center; justify-content: center; margin-left: 8px; }
    .v2 .hd-right { display: flex; align-items: center; gap: 8px; }
    .v2 .hd-right a { font-size: 14px; font-weight: 500; padding: 10px 14px; border-radius: 999px; cursor: pointer; }
    .v2 .hd-right a:hover { background: #f7f7f7; }
    .v2 .container { max-width: 1180px; margin: 0 auto; padding: 0 56px; }
    .v2 .filters { display: flex; align-items: center; gap: 28px; padding: 24px 56px; max-width: 1180px; margin: 0 auto; overflow-x: auto; border-bottom: 1px solid #ebebeb; }
    .v2 .filt { display: flex; flex-direction: column; align-items: center; gap: 6px; padding: 8px 0; opacity: 0.65; cursor: pointer; flex-shrink: 0; min-width: 64px; border-bottom: 2px solid transparent; }
    .v2 .filt.active { opacity: 1; border-bottom-color: #222; }
    .v2 .filt:hover { opacity: 1; }
    .v2 .filt-label { font-size: 12px; font-weight: 500; white-space: nowrap; }
    .v2 .breadcrumb { font-size: 14px; color: #484848; padding: 24px 0 0; }
    .v2 .breadcrumb a { text-decoration: underline; cursor: pointer; }
    .v2 .listing-head { padding: 12px 0 16px; }
    .v2 .listing-head h1 { font-size: 28px; font-weight: 600; margin: 0 0 6px; letter-spacing: -0.01em; }
    .v2 .listing-head .meta { font-size: 14px; color: #222; display: flex; gap: 4px; align-items: center; }
    .v2 .listing-head .meta a { text-decoration: underline; cursor: pointer; }
    .v2 .listing-head .meta .sep { color: #767676; }
    .v2 .gallery { display: grid; grid-template-columns: 2fr 1fr 1fr; grid-template-rows: 220px 220px; gap: 8px; border-radius: 16px; overflow: hidden; margin-bottom: 32px; }
    .v2 .gallery > :first-child { grid-row: 1 / 3; }
    .v2 .gallery > *:not(.gallery-btn) { width: 100%; height: 100%; }
    .v2 .gallery > *:not(.gallery-btn) > div { border-radius: 0 !important; height: 100% !important; }
    .v2 .gallery-btn { position: absolute; bottom: 16px; right: 16px; padding: 8px 14px; background: #fff; border: 1px solid #222; border-radius: 8px; font-size: 13px; font-weight: 600; cursor: pointer; }
    .v2 .body { display: grid; grid-template-columns: 1fr 380px; gap: 80px; padding-bottom: 64px; }
    .v2 .sec-host { display: flex; align-items: center; justify-content: space-between; padding: 24px 0; border-bottom: 1px solid #ebebeb; }
    .v2 .sec-host h2 { font-size: 22px; font-weight: 600; margin: 0 0 6px; }
    .v2 .sec-host p { font-size: 15px; color: #767676; margin: 0; }
    .v2 .sec-host .ava { width: 56px; height: 56px; border-radius: 50%; background: var(--accent); color: #fff; display: flex; align-items: center; justify-content: center; font-weight: 700; font-size: 20px; }
    .v2 .features { padding: 32px 0; border-bottom: 1px solid #ebebeb; display: flex; flex-direction: column; gap: 20px; }
    .v2 .feature { display: grid; grid-template-columns: 28px 1fr; gap: 18px; align-items: start; padding: 6px 0; }
    .v2 .feature h3 { font-size: 17px; font-weight: 600; margin: 0 0 4px; letter-spacing: -0.005em; }
    .v2 .feature p { font-size: 14px; color: #767676; margin: 0; line-height: 1.5; }
    .v2 .feature svg { color: #222; }
    .v2 .desc { padding: 32px 0; border-bottom: 1px solid #ebebeb; }
    .v2 .desc h2 { font-size: 22px; font-weight: 600; margin: 0 0 16px; }
    .v2 .desc p { font-size: 16px; line-height: 1.55; color: #222; margin: 0 0 12px; }
    .v2 .desc p em { font-style: normal; font-weight: 600; }
    .v2 .ame { padding: 32px 0; border-bottom: 1px solid #ebebeb; }
    .v2 .ame h2 { font-size: 22px; font-weight: 600; margin: 0 0 20px; }
    .v2 .ame-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 12px; }
    .v2 .ame-item { display: flex; align-items: center; gap: 12px; padding: 10px 0; font-size: 15px; }
    .v2 .ame-item svg { color: #222; flex-shrink: 0; }
    .v2 .calendar-hint { padding: 32px 0; border-bottom: 1px solid #ebebeb; }
    .v2 .calendar-hint h2 { font-size: 22px; font-weight: 600; margin: 0 0 6px; }
    .v2 .calendar-hint .sub { font-size: 14px; color: #767676; margin: 0 0 20px; }
    .v2 .timeline { display: grid; grid-template-columns: repeat(3, 1fr); gap: 12px; }
    .v2 .day { padding: 16px; border: 1px solid #ebebeb; border-radius: 12px; }
    .v2 .day-num { font-size: 12px; font-weight: 700; color: var(--accent); letter-spacing: 0.05em; text-transform: uppercase; margin-bottom: 8px; }
    .v2 .day h4 { font-size: 15px; font-weight: 600; margin: 0 0 4px; }
    .v2 .day p { font-size: 13px; color: #767676; margin: 0; line-height: 1.4; }
    .v2 .reviews { padding: 32px 0; }
    .v2 .reviews-head { display: flex; align-items: center; gap: 8px; margin-bottom: 24px; font-size: 22px; font-weight: 600; }
    .v2 .review-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 32px 48px; }
    .v2 .review { }
    .v2 .review-head { display: flex; align-items: center; gap: 12px; margin-bottom: 8px; }
    .v2 .review-ava { width: 40px; height: 40px; border-radius: 50%; overflow: hidden; }
    .v2 .review-ava > div { height: 100% !important; border-radius: 0 !important; }
    .v2 .review-name { font-size: 15px; font-weight: 600; }
    .v2 .review-when { font-size: 13px; color: #767676; }
    .v2 .review-stars { display: flex; gap: 2px; margin-bottom: 6px; color: #222; }
    .v2 .review p { font-size: 14px; color: #222; margin: 0; line-height: 1.5; }
    /* Booking card (sticky) */
    .v2 .book { position: sticky; top: 100px; padding: 24px; border: 1px solid #ddd; border-radius: 16px; box-shadow: 0 6px 20px rgba(0,0,0,0.10); height: fit-content; }
    .v2 .book-price { display: flex; align-items: baseline; gap: 6px; margin-bottom: 16px; }
    .v2 .book-price .num { font-size: 26px; font-weight: 700; }
    .v2 .book-price .unit { font-size: 15px; color: #222; }
    .v2 .book-form { border: 1px solid #b0b0b0; border-radius: 8px; overflow: hidden; }
    .v2 .book-row { display: grid; grid-template-columns: 1fr 1fr; }
    .v2 .book-fld { padding: 10px 12px; border-bottom: 1px solid #b0b0b0; }
    .v2 .book-fld + .book-fld { border-left: 1px solid #b0b0b0; }
    .v2 .book-fld-last { padding: 10px 12px; }
    .v2 .book-lbl { font-size: 10px; font-weight: 700; text-transform: uppercase; letter-spacing: 0.05em; }
    .v2 .book-val { font-size: 14px; color: #222; margin-top: 2px; }
    .v2 .reserve-btn { width: 100%; margin-top: 16px; padding: 14px; background: var(--accent); color: #fff; border: none; border-radius: 8px; font-size: 16px; font-weight: 600; cursor: pointer; }
    .v2 .reserve-btn:hover { background: var(--accent-dark); }
    .v2 .book-fee { display: flex; justify-content: space-between; padding: 10px 0; font-size: 15px; }
    .v2 .book-fee.total { border-top: 1px solid #ebebeb; padding-top: 14px; margin-top: 8px; font-weight: 600; font-size: 16px; }
    .v2 .book-note { font-size: 12px; color: #767676; text-align: center; margin: 12px 0 0; }
  `;
  return (
    <div className="v2">
      <style dangerouslySetInnerHTML={{__html: css}}/>

      <header className="hd">
        <div className="hd-in">
          <Logo size={26}/>
          <div className="hd-search">
            <div className="hd-search-seg">Ton métier<span>Plombier</span></div>
            <div className="hd-search-seg">Ce qu'il te faut<span>Site web</span></div>
            <div className="hd-search-seg">Quand<span>Ce mois-ci</span></div>
            <div className="hd-search-cta"><svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="3" strokeLinecap="round"><circle cx="11" cy="11" r="8"/><line x1="21" y1="21" x2="16.65" y2="16.65"/></svg></div>
          </div>
          <div className="hd-right">
            <a>Devenir client</a>
            <a><Icon.Globe size={16}/></a>
          </div>
        </div>
      </header>

      <div className="filters">
        {[{l: "Plombier", i: "Wrench", a: true},{l: "Électricien", i: "Plug"},{l: "Maçon", i: "Hammer"},{l: "Peintre", i: "Brush"},{l: "Coiffeur", i: "Scissors"},{l: "Boulanger", i: "Croissant"},{l: "Garagiste", i: "Wrench"},{l: "Fleuriste", i: "Sparkle"},{l: "Tous", i: "Sparkle"}].map((f, i) => {
          const I = Icon[f.i] || Icon.Sparkle;
          return <div key={i} className={`filt ${f.a ? "active" : ""}`}><I size={22}/><div className="filt-label">{f.l}</div></div>;
        })}
      </div>

      <div className="container">
        <div className="breadcrumb"><a>Accueil</a> · <a>Offres</a> · Site web pro pour artisans</div>
        <div className="listing-head">
          <h1>Site web pro · livré en 15 jours · prix fixe</h1>
          <div className="meta">
            <Icon.Star size={14}/><b>4,9</b><span className="sep">·</span><a>87 réalisations</a><span className="sep">·</span><a>Lyon, France · Toute la France</a><span className="sep">·</span><span style={{background: "#FFF1F1", color: "var(--accent)", padding: "3px 10px", borderRadius: 999, fontSize: 12, fontWeight: 600, marginLeft: 6}}>★ Superpro</span>
          </div>
        </div>

        <div className="gallery" style={{position: "relative"}}>
          <div><CraftPlaceholder kind="site" tone="cream"/></div>
          <div><CraftPlaceholder kind="laptop" tone="sand"/></div>
          <div><CraftPlaceholder kind="portrait" tone="warm"/></div>
          <div><CraftPlaceholder kind="tools" tone="sage"/></div>
          <div><CraftPlaceholder kind="shop" tone="rose"/></div>
          <button className="gallery-btn">Voir les 12 photos</button>
        </div>

        <div className="body">
          <div>
            <section className="sec-host">
              <div>
                <h2>Conçu par Mathieu, fondateur Manéo</h2>
                <p>8 ans dans le sanitaire chez Presto · 87 sites livrés · répond en 2h</p>
              </div>
              <div className="ava">M</div>
            </section>

            <section className="features">
              <div className="feature">
                <Icon.Euro size={26}/>
                <div><h3>990€ tout compris</h3><p>Prix fixe annoncé dès le premier appel. Pas d'options cachées, pas de "et en plus il faudrait…". Le devis qu'on signe est celui qu'on paie.</p></div>
              </div>
              <div className="feature">
                <Icon.Calendar size={26}/>
                <div><h3>Livré en 15 jours</h3><p>Du premier appel à la mise en ligne. 15 jours ouvrés. Si je dépasse, tu paies pas la dernière semaine. Engagement contractuel.</p></div>
              </div>
              <div className="feature">
                <Icon.Smile size={26}/>
                <div><h3>Zéro jargon</h3><p>« Hosting », « SEO », « CMS », « responsive » — on s'en fout. Tu m'expliques ton métier, je te livre un site qui ramène des clients. C'est tout.</p></div>
              </div>
            </section>

            <section className="desc">
              <h2>Ce que tu vas avoir</h2>
              <p>Un site qui te ressemble — pas un truc générique avec ton nom collé dessus. <em>5 pages bien fichues</em> : accueil, services, réalisations, à propos, contact. Photos pro de ton atelier ou ta boutique (je viens les faire), formulaire de devis qui arrive direct sur ton tél, fiche Google Maps optimisée, et tu apparais quand on cherche ton métier dans ta ville.</p>
              <p>Et après les 15 jours, tu repars avec un site dont <em>tu es propriétaire</em>. Hébergement et nom de domaine pour 1 an inclus. Si tu veux changer un mot, ajouter une photo : je te montre, ça prend 30 secondes.</p>
            </section>

            <section className="ame">
              <h2>Ce qui est inclus</h2>
              <div className="ame-grid">
                {[
                  ["Sparkle", "Design sur mesure"],
                  ["MapPin", "Fiche Google Business"],
                  ["Phone", "Formulaire devis SMS"],
                  ["Heart", "Photos pro de ton activité"],
                  ["Globe", "Nom de domaine 1 an"],
                  ["Code", "Hébergement 1 an"],
                  ["Mail", "Adresse email pro"],
                  ["Wrench", "Maintenance 3 mois"],
                ].map(([k, l]) => {
                  const I = Icon[k];
                  return <div key={l} className="ame-item"><I size={22}/>{l}</div>;
                })}
              </div>
            </section>

            <section className="calendar-hint">
              <h2>15 jours. Voilà à quoi ça ressemble.</h2>
              <p className="sub">Du 12 mai au 27 mai, par exemple.</p>
              <div className="timeline">
                <div className="day"><div className="day-num">Jour 1</div><h4>On parle 1h</h4><p>Chez toi. Tu me racontes, je note. Café offert.</p></div>
                <div className="day"><div className="day-num">Jour 5</div><h4>Première version</h4><p>Tu vois ton site, tu me dis ce qui colle.</p></div>
                <div className="day"><div className="day-num">Jour 15</div><h4>En ligne</h4><p>Mise en ligne ensemble. Tu repars autonome.</p></div>
              </div>
            </section>

            <section className="reviews">
              <div className="reviews-head"><Icon.Star size={20}/>4,9 · 87 réalisations</div>
              <div className="review-grid">
                {MANEO_REVIEWS.map((r, i) => (
                  <div key={i} className="review">
                    <div className="review-head">
                      <div className="review-ava"><CraftPlaceholder kind={r.kind} tone={r.tone}/></div>
                      <div><div className="review-name">{r.name}</div><div className="review-when">{r.trade}</div></div>
                    </div>
                    <div className="review-stars">{[0,1,2,3,4].map(j => <Icon.Star key={j} size={12}/>)}</div>
                    <p>« {r.quote} »</p>
                  </div>
                ))}
              </div>
            </section>
          </div>

          <aside>
            <div className="book">
              <div className="book-price">
                <span className="num">990€</span>
                <span className="unit">prix fixe, tout compris</span>
              </div>
              <div className="book-form">
                <div className="book-row">
                  <div className="book-fld"><div className="book-lbl">Démarrage</div><div className="book-val">12 mai 2026</div></div>
                  <div className="book-fld"><div className="book-lbl">Mise en ligne</div><div className="book-val">27 mai 2026</div></div>
                </div>
                <div className="book-row">
                  <div className="book-fld"><div className="book-lbl">Métier</div><div className="book-val">Plombier</div></div>
                  <div className="book-fld"><div className="book-lbl">Ville</div><div className="book-val">Lyon</div></div>
                </div>
                <div className="book-fld-last"><div className="book-lbl">Pages</div><div className="book-val">5 pages · sur mesure</div></div>
              </div>
              <button className="reserve-btn">Caler 1h gratuit</button>
              <div className="book-note">Pas débité tant qu'on s'est pas vus</div>
              <div style={{marginTop: 24}}>
                <div className="book-fee"><span style={{textDecoration: "underline"}}>Site web · pack 5 pages</span><span>990€</span></div>
                <div className="book-fee"><span style={{textDecoration: "underline"}}>Photos pro incluses</span><span>0€</span></div>
                <div className="book-fee"><span style={{textDecoration: "underline"}}>Hébergement an 1</span><span>0€</span></div>
                <div className="book-fee total"><span>Total</span><span>990€</span></div>
              </div>
              <div style={{marginTop: 16, padding: 14, border: "1px solid #ebebeb", borderRadius: 12, fontSize: 13, color: "#484848", display: "flex", gap: 10}}>
                <Icon.Sparkle size={16}/><span><b>Trouvaille rare.</b> Le site de Mathieu est généralement réservé un mois à l'avance.</span>
              </div>
            </div>
          </aside>
        </div>
      </div>
    </div>
  );
}

window.ManeoV2 = ManeoV2;
