// Composants Manéo partagés — animations + 3 offres

// ====== Hook scroll reveal ======
function useReveal() {
  const ref = React.useRef(null);
  const [shown, setShown] = React.useState(false);
  React.useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const io = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) { setShown(true); io.disconnect(); }
    }, { threshold: 0.12, rootMargin: "0px 0px -8% 0px" });
    io.observe(el);
    return () => io.disconnect();
  }, []);
  return [ref, shown];
}

function Reveal({ children, delay = 0, y = 24, as: Tag = "div", style, ...rest }) {
  const [ref, shown] = useReveal();
  return (
    <Tag ref={ref} style={{
      ...style,
      opacity: shown ? 1 : 0,
      transform: shown ? "translateY(0)" : `translateY(${y}px)`,
      transition: `opacity 700ms cubic-bezier(0.2,0,0,1) ${delay}ms, transform 700ms cubic-bezier(0.2,0,0,1) ${delay}ms`,
    }} {...rest}>{children}</Tag>
  );
}

// ====== Logos / wordmarks ======
function ManeoLogoA({ size = 28, color = "currentColor" }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "baseline", gap: 0, fontFamily: "var(--font-sans)", fontWeight: 800, fontSize: size, letterSpacing: "-0.04em", color, lineHeight: 1 }}>
      <span>Man</span>
      <span style={{ position: "relative", display: "inline-block" }}>
        é
        <span style={{ position: "absolute", left: "50%", top: "-0.15em", transform: "translateX(-50%)", width: "0.35em", height: "0.12em", background: "var(--accent, #FF5A5F)", borderRadius: 2 }}></span>
      </span>
      <span>o.</span>
    </span>
  );
}

function ManeoLogoB({ size = 28, color = "currentColor" }) {
  const s = size;
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 8, fontFamily: "var(--font-sans)", fontWeight: 700, fontSize: s, letterSpacing: "-0.03em", color, lineHeight: 1 }}>
      <svg width={s * 1.05} height={s * 1.05} viewBox="0 0 32 32" fill="none">
        <path d="M4 26 L4 10 L16 18 L28 10 L28 26" stroke="var(--accent, #FF5A5F)" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
      </svg>
      <span>Manéo</span>
    </span>
  );
}

function ManeoLogoC({ size = 28, color = "currentColor" }) {
  return (
    <span style={{ display: "inline-flex", alignItems: "center", gap: 10, fontFamily: "var(--font-sans)", fontWeight: 700, fontSize: size, color, lineHeight: 1 }}>
      <span style={{ width: size * 1.4, height: size * 1.4, borderRadius: "50%", background: "var(--accent, #FF5A5F)", color: "#fff", display: "inline-flex", alignItems: "center", justifyContent: "center", fontSize: size * 0.7, fontWeight: 800, letterSpacing: "-0.04em" }}>M</span>
      <span style={{ letterSpacing: "-0.03em" }}>Manéo</span>
    </span>
  );
}

// ====== Icônes ======
const Icon = {
  Check: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><polyline points="20 6 9 17 4 12"/></svg>,
  Arrow: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><line x1="5" y1="12" x2="19" y2="12"/><polyline points="12 5 19 12 12 19"/></svg>,
  Calendar: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><rect x="3" y="4" width="18" height="18" rx="2"/><line x1="16" y1="2" x2="16" y2="6"/><line x1="8" y1="2" x2="8" y2="6"/><line x1="3" y1="10" x2="21" y2="10"/></svg>,
  Euro: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M14 22a8 8 0 1 1 0-16"/><line x1="3" y1="10" x2="13" y2="10"/><line x1="3" y1="14" x2="11" y2="14"/></svg>,
  Wrench: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M14.7 6.3a1 1 0 0 0 0 1.4l1.6 1.6a1 1 0 0 0 1.4 0l3.77-3.77a6 6 0 0 1-7.94 7.94l-6.91 6.91a2.12 2.12 0 0 1-3-3l6.91-6.91a6 6 0 0 1 7.94-7.94l-3.76 3.76z"/></svg>,
  Phone: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>,
  Mail: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>,
  MapPin: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0 1 18 0z"/><circle cx="12" cy="10" r="3"/></svg>,
  Star: (p) => <svg width={p.size||16} height={p.size||16} viewBox="0 0 24 24" fill="currentColor" {...p}><polygon points="12 2 15.09 8.26 22 9.27 17 14.14 18.18 21.02 12 17.77 5.82 21.02 7 14.14 2 9.27 8.91 8.26 12 2"/></svg>,
  Hammer: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M15 12l-8.5 8.5a2.12 2.12 0 0 1-3-3L12 9"/><path d="M17.64 15 22 10.64"/><path d="M20.91 11.7a2.81 2.81 0 0 0 0-3.96 2.81 2.81 0 0 0-3.96 0L9 16l3 3 7.91-7.3z"/></svg>,
  Plug: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12 22v-5"/><path d="M9 8V2"/><path d="M15 8V2"/><path d="M18 8v5a4 4 0 0 1-4 4h-4a4 4 0 0 1-4-4V8z"/></svg>,
  Brush: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m9.06 11.9 8.07-8.06a2.85 2.85 0 1 1 4.03 4.03l-8.06 8.08"/><path d="M7.07 14.94c-1.66 0-3 1.35-3 3.02 0 1.33-2.5 1.52-2 2.02 1.08 1.1 2.49 2.02 4 2.02 2.2 0 4-1.8 4-4.04a3.01 3.01 0 0 0-3-3.02z"/></svg>,
  Scissors: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="6" cy="6" r="3"/><circle cx="6" cy="18" r="3"/><line x1="20" y1="4" x2="8.12" y2="15.88"/><line x1="14.47" y1="14.48" x2="20" y2="20"/><line x1="8.12" y1="8.12" x2="12" y2="12"/></svg>,
  Croissant: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="m4.6 13.11 5.79-3.21c1.89-1.05 4.79 1.78 3.71 3.71l-3.22 5.81C8.8 23.16.79 15.23 4.6 13.11Z"/><path d="m10.5 9.5-1-2.29C9.2 6.48 8.8 6 8 6H4.5C2.79 6 2 6.5 2 8.5a7.71 7.71 0 0 0 2 4.83"/><path d="M8 6c0-1.55.24-4-2-4-2 0-2.5 2.17-2.5 4"/><path d="m14.5 13.5 2.29 1c.73.3 1.21.7 1.21 1.5v3.5c0 1.71-.5 2.5-2.5 2.5a7.71 7.71 0 0 1-4.83-2"/><path d="M18 16c1.55 0 4-.24 4 2 0 2-2.17 2.5-4 2.5"/></svg>,
  Smile: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="12" cy="12" r="10"/><path d="M8 14s1.5 2 4 2 4-2 4-2"/><line x1="9" y1="9" x2="9.01" y2="9"/><line x1="15" y1="9" x2="15.01" y2="9"/></svg>,
  Code: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><polyline points="16 18 22 12 16 6"/><polyline points="8 6 2 12 8 18"/></svg>,
  Heart: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/></svg>,
  Globe: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="12" cy="12" r="10"/><line x1="2" y1="12" x2="22" y2="12"/><path d="M12 2a15.3 15.3 0 0 1 4 10 15.3 15.3 0 0 1-4 10 15.3 15.3 0 0 1-4-10 15.3 15.3 0 0 1 4-10z"/></svg>,
  Sparkle: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><path d="M12 3v3M12 18v3M3 12h3M18 12h3M5.6 5.6l2.1 2.1M16.3 16.3l2.1 2.1M5.6 18.4l2.1-2.1M16.3 7.7l2.1-2.1"/></svg>,
  Layers: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><polygon points="12 2 2 7 12 12 22 7 12 2"/><polyline points="2 17 12 22 22 17"/><polyline points="2 12 12 17 22 12"/></svg>,
  Cog: (p) => <svg width={p.size||20} height={p.size||20} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" {...p}><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 1 1-4 0v-.09a1.65 1.65 0 0 0-1-1.51 1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.65 1.65 0 0 0 .33-1.82 1.65 1.65 0 0 0-1.51-1H3a2 2 0 1 1 0-4h.09a1.65 1.65 0 0 0 1.51-1 1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.65 1.65 0 0 0 1.82.33h0a1.65 1.65 0 0 0 1-1.51V3a2 2 0 1 1 4 0v.09a1.65 1.65 0 0 0 1 1.51h0a1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.65 1.65 0 0 0-.33 1.82v0a1.65 1.65 0 0 0 1.51 1H21a2 2 0 1 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>,
};

// ====== Placeholder visuel ======
function CraftPlaceholder({ kind = "build", tone = "warm", aspect = "1/1", label }) {
  const palettes = {
    warm:    { bg: "#F4E3D0", fg: "#8B5A3C", line: "#C99877" },
    sand:    { bg: "#EDE3D2", fg: "#7A5C3E", line: "#B89674" },
    sage:    { bg: "#D8E2D2", fg: "#4F6B47", line: "#8FAA85" },
    sky:     { bg: "#D7E2EA", fg: "#3D5A6B", line: "#7E9AAB" },
    clay:    { bg: "#E8C9B5", fg: "#7A4A30", line: "#BD8567" },
    cream:   { bg: "#F2EAD9", fg: "#6B5839", line: "#B8A47A" },
    rose:    { bg: "#F0D4D2", fg: "#8B4744", line: "#C58884" },
    olive:   { bg: "#DDD9C0", fg: "#5C5A3A", line: "#9B967A" },
    night:   { bg: "#22272E", fg: "#E8DFD0", line: "#5A6470" },
  };
  const p = palettes[tone] || palettes.warm;
  const scenes = {
    build: ( <g><rect x="20" y="60" width="40" height="35" fill={p.line} opacity="0.4"/><polygon points="20,60 40,42 60,60" fill={p.fg} opacity="0.6"/><rect x="33" y="75" width="14" height="20" fill={p.bg}/><line x1="70" y1="20" x2="70" y2="95" stroke={p.fg} strokeWidth="1.5"/><line x1="70" y1="20" x2="92" y2="20" stroke={p.fg} strokeWidth="1.5"/><line x1="85" y1="20" x2="85" y2="35" stroke={p.fg} strokeWidth="1"/><rect x="80" y="35" width="10" height="6" fill={p.line} opacity="0.6"/></g> ),
    tools: ( <g transform="translate(50 50)"><g transform="rotate(-30)"><rect x="-30" y="-3" width="40" height="6" rx="2" fill={p.fg}/><rect x="10" y="-10" width="14" height="20" rx="2" fill={p.line}/></g><g transform="rotate(45) translate(10 0)"><circle cx="0" cy="-15" r="8" fill="none" stroke={p.fg} strokeWidth="3"/><rect x="-2" y="-10" width="4" height="28" fill={p.fg}/></g></g> ),
    shop: ( <g><rect x="15" y="40" width="70" height="55" fill={p.bg} stroke={p.fg} strokeWidth="1.5"/><polygon points="10,40 50,18 90,40" fill={p.fg} opacity="0.7"/><rect x="22" y="50" width="20" height="20" fill={p.line} opacity="0.5"/><rect x="58" y="50" width="20" height="20" fill={p.line} opacity="0.5"/><rect x="42" y="65" width="16" height="30" fill={p.fg}/><circle cx="56" cy="80" r="1.5" fill={p.bg}/></g> ),
    laptop: ( <g><rect x="20" y="30" width="60" height="40" rx="3" fill={p.fg}/><rect x="24" y="34" width="52" height="32" fill={p.bg}/><rect x="28" y="38" width="20" height="3" fill={p.line}/><rect x="28" y="44" width="44" height="2" fill={p.line} opacity="0.5"/><rect x="28" y="49" width="36" height="2" fill={p.line} opacity="0.5"/><rect x="28" y="56" width="14" height="6" rx="1" fill={p.fg}/><rect x="14" y="70" width="72" height="4" rx="1" fill={p.fg}/></g> ),
    portrait: ( <g><circle cx="50" cy="40" r="14" fill={p.fg}/><path d="M 22 95 Q 22 65 50 65 Q 78 65 78 95 Z" fill={p.fg}/><rect x="40" y="68" width="20" height="6" fill={p.line}/></g> ),
    door: ( <g><rect x="15" y="15" width="70" height="80" fill={p.bg} stroke={p.fg} strokeWidth="1"/><rect x="30" y="30" width="40" height="55" fill={p.line} opacity="0.5"/><line x1="50" y1="30" x2="50" y2="85" stroke={p.fg} strokeWidth="1"/><line x1="30" y1="57" x2="70" y2="57" stroke={p.fg} strokeWidth="1"/></g> ),
    site: ( <g><rect x="12" y="22" width="76" height="60" rx="3" fill={p.bg} stroke={p.fg} strokeWidth="1.5"/><rect x="12" y="22" width="76" height="8" fill={p.fg}/><circle cx="18" cy="26" r="1.2" fill={p.bg}/><circle cx="22" cy="26" r="1.2" fill={p.bg}/><circle cx="26" cy="26" r="1.2" fill={p.bg}/><rect x="18" y="35" width="30" height="4" fill={p.fg}/><rect x="18" y="42" width="50" height="2" fill={p.line} opacity="0.6"/><rect x="18" y="46" width="42" height="2" fill={p.line} opacity="0.6"/><rect x="18" y="56" width="16" height="6" rx="1" fill={p.fg}/><rect x="56" y="38" width="26" height="30" fill={p.line} opacity="0.4"/></g> ),
    handshake: ( <g transform="translate(0 10)"><path d="M 15 50 L 35 35 L 50 45 L 65 35 L 85 50 L 75 65 L 50 70 L 25 65 Z" fill={p.fg}/><line x1="50" y1="45" x2="50" y2="65" stroke={p.bg} strokeWidth="2"/></g> ),
    plant: ( <g><rect x="38" y="65" width="24" height="25" rx="2" fill={p.fg}/><path d="M 50 65 Q 35 50 30 30 Q 45 35 50 55" fill={p.line}/><path d="M 50 65 Q 65 50 70 30 Q 55 35 50 55" fill={p.fg} opacity="0.7"/><line x1="50" y1="65" x2="50" y2="40" stroke={p.bg} strokeWidth="1.5"/></g> ),
  };
  return (
    <div style={{ aspectRatio: aspect, width: "100%", background: p.bg, borderRadius: 12, overflow: "hidden", position: "relative", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <svg viewBox="0 0 100 100" preserveAspectRatio="xMidYMid meet" style={{ width: "100%", height: "100%" }}>{scenes[kind] || scenes.build}</svg>
      {label && <div style={{ position: "absolute", left: 12, bottom: 12, background: "rgba(255,255,255,0.92)", color: "#222", fontSize: 12, fontWeight: 600, padding: "4px 10px", borderRadius: 6 }}>{label}</div>}
    </div>
  );
}

// ====== Données partagées ======
const MANEO_REVIEWS = [
  { name: "Karim", trade: "Plombier · Lyon 7e", quote: "Avant Manéo, j'avais rien. 3 semaines après le site, 2 chantiers que j'aurais jamais eus.", tone: "warm", kind: "tools" },
  { name: "Sophie", trade: "Boulangerie · Nantes", quote: "Il a compris ma boutique en 1h. Le site ressemble à mon magasin, pas à un truc générique.", tone: "cream", kind: "shop" },
  { name: "David", trade: "Électricien · Lille", quote: "L'appli devis me fait gagner 5h par semaine. Sérieux. Plus de retours arrière sur Excel.", tone: "sky", kind: "laptop" },
  { name: "Léa", trade: "Coiffeuse · Toulouse", quote: "Prix annoncé, prix payé. Livré le jour dit. Aucune mauvaise surprise, ça change.", tone: "rose", kind: "portrait" },
];

const MANEO_TRADES = [
  { icon: "Wrench",   label: "Plombier" },
  { icon: "Plug",     label: "Électricien" },
  { icon: "Hammer",   label: "Maçon" },
  { icon: "Brush",    label: "Peintre" },
  { icon: "Scissors", label: "Coiffeur" },
  { icon: "Croissant",label: "Boulanger" },
];

// ====== 3 OFFRES SITES ======
const MANEO_PACKS = [
  {
    id: "essentiel",
    name: "Essentiel",
    tagline: "Pour exister en ligne, sérieusement.",
    price: 990,
    delay: "15 jours",
    pages: "3 pages",
    accent: false,
    features: [
      "3 pages : accueil, services, contact",
      "Design sur mesure (pas un template)",
      "Photos pro de ton activité (je viens les faire)",
      "Fiche Google Business optimisée",
      "Formulaire devis qui arrive sur ton tél",
      "Hébergement + nom de domaine 1 an",
    ],
    cta: "Choisir l'Essentiel",
  },
  {
    id: "pro",
    name: "Pro",
    tagline: "Pour vraiment ramener des clients.",
    price: 1890,
    delay: "3 semaines",
    pages: "6 pages",
    accent: true,
    badge: "Le plus pris",
    features: [
      "6 pages : + réalisations, à propos, blog",
      "Galerie chantiers/avant-après illimitée",
      "Référencement local pro (10 villes ciblées)",
      "Avis Google intégrés en direct",
      "Page tarifs transparente (calculateur)",
      "Hébergement + domaine + maintenance 1 an",
      "Formation 2h pour gérer ton site seul",
    ],
    cta: "Choisir le Pro",
  },
  {
    id: "signature",
    name: "Signature",
    tagline: "Pour devenir la référence de ton secteur.",
    price: 3490,
    delay: "5 semaines",
    pages: "Sur mesure",
    accent: false,
    features: [
      "Pages illimitées · architecture sur mesure",
      "Identité visuelle : logo + charte graphique",
      "Shooting photo pro (½ journée incluse)",
      "Vidéo de présentation 60 secondes",
      "Espace client (devis, factures, photos)",
      "Référencement local national + Google Ads",
      "Suivi mensuel pendant 6 mois",
    ],
    cta: "Discuter du Signature",
  },
];

Object.assign(window, {
  ManeoLogoA, ManeoLogoB, ManeoLogoC,
  Icon, CraftPlaceholder, Reveal, useReveal,
  MANEO_REVIEWS, MANEO_TRADES, MANEO_PACKS,
});
