// V3 — Storytelling vertical : full-bleed, ton très perso, le brief raconté étape par étape

function ManeoV3({ density = "comfortable", logoVariant = "C" }) {
  const Logo = { A: ManeoLogoA, B: ManeoLogoB, C: ManeoLogoC }[logoVariant] || ManeoLogoC;
  const pad = density === "compact" ? { sec: 80 } : { sec: 120 };
  const css = `
    .v3 { font-family: var(--font-sans); color: #222; background: #FFFCF6; width: 1280px; }
    @keyframes v3reveal { from { opacity: 0; transform: translateY(20px); } to { opacity: 1; transform: translateY(0); } }
    @keyframes v3underline { from { transform: scaleX(0); } to { transform: scaleX(1); } }
    .v3 h1 { animation: v3reveal 900ms cubic-bezier(0.2,0,0,1) both; }
    .v3 .hero-sub { animation: v3reveal 900ms cubic-bezier(0.2,0,0,1) 200ms both; }
    .v3 .hero-cta { animation: v3reveal 900ms cubic-bezier(0.2,0,0,1) 400ms both; }
    .v3 h1 .underline::after { transform-origin: left; animation: v3underline 800ms cubic-bezier(0.2,0,0,1) 600ms both; }
    .v3 .ocard { transition: transform 300ms cubic-bezier(0.2,0,0,1), box-shadow 300ms; }
    .v3 .ocard:hover { transform: translateY(-8px); box-shadow: 0 24px 60px rgba(0,0,0,0.18); }
    .v3 .promise-num { transition: transform 300ms cubic-bezier(0.2,0,0,1); display: inline-block; }
    .v3 .promise-item:hover .promise-num { transform: scale(1.08); }
    .v3 .hd { display: flex; align-items: center; padding: 24px 64px; justify-content: space-between; }
    .v3 .hd-nav { display: flex; gap: 32px; align-items: center; }
    .v3 .hd-nav a { font-size: 14px; font-weight: 500; color: #484848; cursor: pointer; }
    .v3 .btn { display: inline-flex; align-items: center; gap: 8px; padding: 14px 22px; border-radius: 999px; font-size: 14px; font-weight: 600; cursor: pointer; border: none; font-family: inherit; }
    .v3 .btn-primary { background: #222; color: #fff; }
    .v3 .btn-primary:hover { background: #000; }
    .v3 .btn-accent { background: var(--accent); color: #fff; }
    .v3 .btn-accent:hover { background: var(--accent-dark); }
    .v3 .btn-lg { padding: 18px 30px; font-size: 16px; }

    .v3 .hero { padding: ${pad.sec/1.5}px 64px ${pad.sec}px; max-width: 1180px; margin: 0 auto; }
    .v3 .hero-eyebrow { display: inline-flex; align-items: center; gap: 10px; font-size: 13px; font-weight: 600; padding: 8px 14px; border-radius: 999px; background: #fff; border: 1px solid #ebebeb; margin-bottom: 32px; }
    .v3 .hero-eyebrow .pulse { width: 8px; height: 8px; border-radius: 50%; background: var(--accent); animation: v3pulse 1.5s infinite; }
    @keyframes v3pulse { 0%, 100% { opacity: 1; } 50% { opacity: 0.4; } }
    .v3 h1 { font-size: 92px; font-weight: 800; letter-spacing: -0.04em; line-height: 0.95; margin: 0; }
    .v3 h1 .accent { color: var(--accent); font-style: italic; font-weight: 800; }
    .v3 h1 .underline { position: relative; display: inline-block; }
    .v3 h1 .underline::after { content: ''; position: absolute; left: 0; right: 0; bottom: 6px; height: 12px; background: var(--accent); opacity: 0.25; z-index: -1; border-radius: 4px; }
    .v3 .hero-sub { font-size: 22px; line-height: 1.45; color: #484848; max-width: 720px; margin: 32px 0 40px; }
    .v3 .hero-cta { display: flex; gap: 12px; align-items: center; }
    .v3 .hero-cta-meta { font-size: 14px; color: #767676; margin-left: 16px; }

    .v3 .marquee { padding: 24px 0; background: #222; color: #fff; overflow: hidden; }
    .v3 .marquee-track { display: flex; gap: 48px; animation: v3marquee 28s linear infinite; white-space: nowrap; }
    @keyframes v3marquee { from { transform: translateX(0); } to { transform: translateX(-50%); } }
    .v3 .marquee-item { display: inline-flex; align-items: center; gap: 12px; font-size: 18px; font-weight: 500; }
    .v3 .marquee-dot { width: 6px; height: 6px; border-radius: 50%; background: var(--accent); }

    .v3 .story { padding: ${pad.sec}px 64px; max-width: 1080px; margin: 0 auto; }
    .v3 .story-grid { display: grid; grid-template-columns: 80px 1fr; gap: 48px; margin-bottom: 80px; align-items: start; }
    .v3 .story-num { font-size: 64px; font-weight: 800; color: var(--accent); line-height: 1; letter-spacing: -0.04em; }
    .v3 .story-content h2 { font-size: 48px; font-weight: 700; letter-spacing: -0.025em; line-height: 1.05; margin: 0 0 20px; }
    .v3 .story-content p { font-size: 19px; line-height: 1.55; color: #222; margin: 0 0 16px; max-width: 680px; }
    .v3 .story-content p em { font-style: normal; font-weight: 600; background: linear-gradient(transparent 60%, rgba(255,90,95,0.25) 60%); padding: 0 2px; }
    .v3 .story-img { aspect-ratio: 5/3; border-radius: 16px; overflow: hidden; margin-top: 24px; max-width: 720px; }

    .v3 .pull { padding: ${pad.sec}px 64px; max-width: 1080px; margin: 0 auto; }
    .v3 .pull-quote { font-size: 56px; font-weight: 700; letter-spacing: -0.03em; line-height: 1.05; color: #222; margin: 0; }
    .v3 .pull-quote .mark { color: var(--accent); }

    .v3 .offers { background: #222; color: #fff; padding: ${pad.sec}px 64px; }
    .v3 .offers-in { max-width: 1180px; margin: 0 auto; }
    .v3 .offers h2 { font-size: 64px; font-weight: 800; letter-spacing: -0.035em; line-height: 1; margin: 0 0 12px; color: #fff; }
    .v3 .offers .sub { font-size: 19px; color: #B0B0B0; margin: 0 0 56px; max-width: 560px; }
    .v3 .offer-cards { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
    .v3 .ocard { background: #fff; color: #222; border-radius: 24px; padding: 36px; }
    .v3 .ocard-tag { display: inline-flex; align-items: center; gap: 6px; padding: 6px 12px; border-radius: 999px; font-size: 12px; font-weight: 700; letter-spacing: 0.04em; text-transform: uppercase; margin-bottom: 24px; }
    .v3 .ocard h3 { font-size: 32px; font-weight: 700; letter-spacing: -0.02em; margin: 0 0 4px; }
    .v3 .ocard .one-liner { font-size: 16px; color: #767676; margin: 0 0 28px; }
    .v3 .ocard-price { display: flex; align-items: baseline; gap: 8px; padding: 20px 0; border-top: 1px solid #ebebeb; border-bottom: 1px solid #ebebeb; margin-bottom: 24px; }
    .v3 .ocard-price .num { font-size: 48px; font-weight: 800; letter-spacing: -0.03em; line-height: 1; }
    .v3 .ocard-price .unit { font-size: 14px; color: #767676; }
    .v3 .ocard ul { list-style: none; padding: 0; margin: 0 0 28px; display: flex; flex-direction: column; gap: 12px; }
    .v3 .ocard li { display: flex; gap: 12px; font-size: 15px; line-height: 1.45; }
    .v3 .ocard li svg { color: var(--accent); flex-shrink: 0; margin-top: 3px; }

    .v3 .promise { padding: ${pad.sec}px 64px; max-width: 1180px; margin: 0 auto; }
    .v3 .promise h2 { font-size: 64px; font-weight: 800; letter-spacing: -0.035em; line-height: 1; margin: 0 0 64px; max-width: 800px; }
    .v3 .promise-grid { display: grid; grid-template-columns: repeat(3, 1fr); gap: 48px; }
    .v3 .promise-item { }
    .v3 .promise-num { font-size: 80px; font-weight: 800; letter-spacing: -0.04em; line-height: 1; color: var(--accent); margin-bottom: 16px; }
    .v3 .promise-item h3 { font-size: 22px; font-weight: 700; margin: 0 0 8px; }
    .v3 .promise-item p { font-size: 15px; line-height: 1.55; color: #484848; margin: 0; }

    .v3 .cta-band { padding: ${pad.sec}px 64px; background: var(--accent); color: #fff; }
    .v3 .cta-band-in { max-width: 980px; margin: 0 auto; text-align: center; }
    .v3 .cta-band h2 { font-size: 80px; font-weight: 800; letter-spacing: -0.04em; line-height: 0.98; margin: 0 0 20px; color: #fff; }
    .v3 .cta-band p { font-size: 22px; line-height: 1.4; margin: 0 0 40px; opacity: 0.92; }
    .v3 .cta-band .btn { background: #fff; color: var(--accent); }
    .v3 .cta-band .btn:hover { background: #FFFCF6; }
    .v3 .cta-band-meta { display: flex; justify-content: center; gap: 32px; margin-top: 32px; font-size: 14px; opacity: 0.85; }
    .v3 .cta-band-meta span { display: inline-flex; align-items: center; gap: 8px; }

    .v3 .ft { padding: 48px 64px 32px; background: #FFFCF6; border-top: 1px solid #ebebeb; }
    .v3 .ft-in { max-width: 1180px; margin: 0 auto; display: flex; justify-content: space-between; align-items: end; gap: 32px; }
    .v3 .ft-tag { font-size: 14px; color: #767676; max-width: 420px; margin: 12px 0 0; }
    .v3 .ft-links { display: flex; gap: 32px; font-size: 14px; color: #484848; }
  `;
  return (
    <div className="v3">
      <style dangerouslySetInnerHTML={{__html: css}}/>

      <header className="hd">
        <Logo size={28}/>
        <div className="hd-nav">
          <a>Mon histoire</a>
          <a>Sites web</a>
          <a>Apps métier</a>
          <a>Tarifs</a>
          <button className="btn btn-primary">Voir des exemples<Icon.Arrow size={14}/></button>
        </div>
      </header>

      <section className="hero">
        <div className="hero-eyebrow"><span className="pulse"></span>Disponible · prochain démarrage le 12 mai</div>
        <h1>L'agence web<br/>qui parle <span className="underline">ta langue.</span><br/><span className="accent">Le digital fait main.</span></h1>
        <p className="hero-sub">Pendant 8 ans j'ai bossé chez Presto, dans le sanitaire. J'ai vu trop d'artisans avec des sites pourris ou pas de site, perdre des clients tous les jours. Du coup, je me suis mis à coder. Pour vous.</p>
        <div className="hero-cta">
          <button className="btn btn-accent btn-lg">Voir des exemples<Icon.Arrow size={16}/></button>
          <button className="btn btn-lg" style={{background: "#fff", color: "#222", border: "1px solid #ebebeb"}}>Caler 1h gratuit</button>
          <span className="hero-cta-meta">Réponse dans la journée. Promis.</span>
        </div>
      </section>

      <div className="marquee">
        <div className="marquee-track">
          {[...Array(2)].flatMap((_, k) => [
            <span key={`${k}-1`} className="marquee-item">990€ prix fixe<span className="marquee-dot"/></span>,
            <span key={`${k}-2`} className="marquee-item">Livré en 15 jours<span className="marquee-dot"/></span>,
            <span key={`${k}-3`} className="marquee-item">Zéro jargon<span className="marquee-dot"/></span>,
            <span key={`${k}-4`} className="marquee-item">87 sites livrés<span className="marquee-dot"/></span>,
            <span key={`${k}-5`} className="marquee-item">Made in Lyon<span className="marquee-dot"/></span>,
            <span key={`${k}-6`} className="marquee-item">Réponse en 2h<span className="marquee-dot"/></span>,
          ])}
        </div>
      </div>

      <section className="story">
        <div className="story-grid">
          <div className="story-num">01</div>
          <div className="story-content">
            <h2>D'abord, j'ai bossé sur les chantiers.</h2>
            <p>8 ans chez Presto, le fabricant de robinetterie. Ma journée : faire le tour des plombiers, des grossistes, des chefs de chantier. Je connais le bruit d'une perceuse à 7h du matin, l'odeur du PVC, et les factures qui traînent dans la boîte à gants.</p>
            <p>Et j'ai vu un truc qui revenait <em>à chaque fois</em> : des artisans formidables, qui taffent 12h par jour, qui ramènent moins de clients que le mec d'à côté qui bosse moitié moins bien — parce que <em>lui, il a un site qui marche</em>.</p>
            <div className="story-img"><CraftPlaceholder kind="tools" tone="warm"/></div>
          </div>
        </div>

        <div className="story-grid">
          <div className="story-num">02</div>
          <div className="story-content">
            <h2>Alors je me suis mis à coder.</h2>
            <p>Le soir, après le boulot. Sur YouTube, Stack Overflow, des bouquins. 18 mois plus tard, je faisais des sites pour des potes plombiers et électriciens. Ils m'envoyaient leurs clients. Ces clients m'envoyaient les leurs.</p>
            <p>Aujourd'hui, j'ai livré <em>87 sites</em> et 12 applis sur mesure. Tous pour des artisans, des commerçants, des indépendants. Pas une seule startup, pas une seule grande boîte. <em>C'est mon créneau, et c'est le seul</em>.</p>
            <div className="story-img"><CraftPlaceholder kind="laptop" tone="sand"/></div>
          </div>
        </div>

        <div className="story-grid">
          <div className="story-num">03</div>
          <div className="story-content">
            <h2>Et c'est devenu Manéo.</h2>
            <p>Je viens te voir. On parle 1h. Tu me dis ton métier, tes clients, ce qui te saoule. <em>15 jours après, t'as un site qui te ramène des clients.</em> Point.</p>
            <p>Et si tu veux aller plus loin, je te développe une appli sur mesure pour ton quotidien — devis automatique, planning chantiers, fiches clients. <em>L'outil pro qui te fait gagner 5h par semaine.</em></p>
          </div>
        </div>
      </section>

      <section className="pull">
        <p className="pull-quote"><span className="mark">«</span> Manéo, c'est l'agence web qui te parle comme un collègue de chantier — pas comme un commercial qui essaie de te fourguer un truc. <span className="mark">»</span></p>
        <p style={{fontSize: 16, color: "#767676", marginTop: 24}}>— Karim, plombier à Lyon. Site livré en mars 2025.</p>
      </section>

      <section className="offers">
        <div className="offers-in">
          <h2>Deux offres.<br/>C'est tout.</h2>
          <p className="sub">Pas de menu à rallonge, pas d'options cachées. Tu choisis, on attaque.</p>
          <div className="offer-cards">
            <article className="ocard">
              <div className="ocard-tag" style={{background: "#FFF1F1", color: "var(--accent)"}}>Le pack de base</div>
              <h3>Site web pro</h3>
              <p className="one-liner">Un vrai site, qui ramène des clients.</p>
              <div className="ocard-price"><span className="num">990€</span><span className="unit">prix fixe · livré en 15 jours</span></div>
              <ul>
                <li><Icon.Check size={18}/>5 pages sur mesure (accueil, services, réalisations, à propos, contact)</li>
                <li><Icon.Check size={18}/>Photos pro de ton activité (je viens les faire)</li>
                <li><Icon.Check size={18}/>Fiche Google Business + référencement local</li>
                <li><Icon.Check size={18}/>Formulaire devis qui arrive direct sur ton tél</li>
                <li><Icon.Check size={18}/>Hébergement + nom de domaine la 1ère année</li>
              </ul>
              <button className="btn btn-accent btn-lg" style={{width: "100%", justifyContent: "center"}}>Voir un exemple<Icon.Arrow size={16}/></button>
            </article>
            <article className="ocard">
              <div className="ocard-tag" style={{background: "#E6F4F2", color: "#00A699"}}>Pour aller plus loin</div>
              <h3>Appli métier sur mesure</h3>
              <p className="one-liner">L'outil qui te fait gagner 5h par semaine.</p>
              <div className="ocard-price"><span className="num">à partir de<br/>2 900€</span><span className="unit">sur devis</span></div>
              <ul>
                <li><Icon.Check size={18}/>Devis auto depuis ton tél · client signe en ligne</li>
                <li><Icon.Check size={18}/>Planning chantiers + rappels SMS auto</li>
                <li><Icon.Check size={18}/>Fiches clients · photos avant/après · historique</li>
                <li><Icon.Check size={18}/>Synchro compta (Sage, Cegid, Excel, ce que tu veux)</li>
                <li><Icon.Check size={18}/>Démo en 10 jours · livraison sous 4 à 8 semaines</li>
              </ul>
              <button className="btn btn-lg" style={{background: "#222", color: "#fff", width: "100%", justifyContent: "center"}}>Discuter de mon besoin<Icon.Arrow size={16}/></button>
            </article>
          </div>
        </div>
      </section>

      <section className="promise">
        <h2>3 promesses.<br/>Mises sur papier, dans le devis.</h2>
        <div className="promise-grid">
          <div className="promise-item">
            <div className="promise-num">990€</div>
            <h3>Prix fixe</h3>
            <p>Le devis qu'on signe est celui qu'on paie. Pas un euro de plus, jamais. Si tu veux ajouter une page, on en reparle — mais le pack de base reste à 990€.</p>
          </div>
          <div className="promise-item">
            <div className="promise-num">15j</div>
            <h3>Délai garanti</h3>
            <p>Du premier appel à la mise en ligne, 15 jours ouvrés. Si je dépasse d'un jour, tu paies pas la dernière semaine. C'est écrit dans le contrat.</p>
          </div>
          <div className="promise-item">
            <div className="promise-num">0</div>
            <h3>Mots compliqués</h3>
            <p>« Hosting », « SEO », « responsive », « CMS » — j'utilise pas ces mots avec toi. Si j'en dis un, t'as le droit de me reprendre. C'est ton site.</p>
          </div>
        </div>
      </section>

      <section className="cta-band">
        <div className="cta-band-in">
          <h2>On commence quand ?</h2>
          <p>1h de discussion, gratuite, sans engagement.<br/>Tu me racontes ton métier, je te dis ce que je peux faire pour toi.</p>
          <button className="btn btn-lg">Caler 1h cette semaine<Icon.Arrow size={16}/></button>
          <div className="cta-band-meta">
            <span><Icon.Phone size={14}/>06 12 34 56 78</span>
            <span><Icon.Mail size={14}/>salut@maneo.fr</span>
            <span><Icon.MapPin size={14}/>Lyon · toute la France</span>
          </div>
        </div>
      </section>

      <footer className="ft">
        <div className="ft-in">
          <div>
            <Logo size={26}/>
            <p className="ft-tag">L'agence web qui parle ta langue. Sites pros pour artisans et commerçants. Lyon, France — toute la France si tu m'invites.</p>
          </div>
          <div className="ft-links">
            <span>© 2026 Manéo</span>
            <span style={{cursor: "pointer"}}>Mentions légales</span>
            <span style={{cursor: "pointer"}}>Confidentialité</span>
          </div>
        </div>
      </footer>
    </div>
  );
}

window.ManeoV3 = ManeoV3;
